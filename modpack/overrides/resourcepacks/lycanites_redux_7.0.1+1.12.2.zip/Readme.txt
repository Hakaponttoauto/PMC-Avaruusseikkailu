Modelpack for lycanites Mobs Mod
  by: https://discord.gg/pjAqvwt

This pack is intended to reskin, redesign and recolour the Models and Sprites inside the Lycanites Mobs Mod
All credits of Mobs and Sprites will be included bellow, please report any bugs on the discord link provided

Models:
The Indominator
EAter
dia
Dragonboy
DL_Baryonyx
ShrekRightT*****le1
Jorris

Sprites and Blocks:
The Indominator
Hadez
Catscythe
